//
// Created by p3531 on 2020/11/13.
//

#include "Figur.h"
